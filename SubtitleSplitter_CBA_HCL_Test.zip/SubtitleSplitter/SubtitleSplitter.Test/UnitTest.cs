﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SubtitleSplitter.Controllers;
using SubtitleSplitter.Models;
using System.Web.Mvc;
using RestSharp;
using System.Text;
using SubtitleSplitter.Utility;
namespace SubtitleSplitter.Test
{
    [TestClass]
    public class UnitTest
    {

        #region WebAPI TestCase
        [TestMethod]
        public void TestSubtitleParseReturnValidData()
        {
            TeletextController objTeletextController = new TeletextController();
            TeletextRequest objTeletextRequest = new TeletextRequest();
            objTeletextRequest.maxLengthOfSubtitle = 5;
            objTeletextRequest.paragraphOfText = "wugruweguirjfgkjfhgk;hgls;ldfslkksdl;kgjrwegj,jfghjfg";
           TeletextResponse objTeletextResponse = objTeletextController.SubtitleParse(objTeletextRequest);

           Assert.IsTrue(objTeletextResponse.subtitleText.Count > 0);
        }
        [TestMethod]
        public void TestSubtitleParseReturnEmpty()
        {
            TeletextController objTeletextController = new TeletextController();
            TeletextRequest objTeletextRequest = new TeletextRequest();
            objTeletextRequest.maxLengthOfSubtitle = 5;
            objTeletextRequest.paragraphOfText = "";
            TeletextResponse objTeletextResponse = objTeletextController.SubtitleParse(objTeletextRequest);

            Assert.IsTrue(objTeletextResponse.subtitleText.Count == 0);
        }

        [TestMethod]
        public void TestSubtitleParseReturnExeception()
        {
            TeletextController objTeletextController = new TeletextController();
            TeletextRequest objTeletextRequest = new TeletextRequest();
            objTeletextRequest.maxLengthOfSubtitle = 0;
            objTeletextRequest.paragraphOfText = "xcvxcvxcvxc fgfgfdgd fgdg dgdfgd";
            TeletextResponse objTeletextResponse = objTeletextController.SubtitleParse(objTeletextRequest);

            Assert.IsTrue(objTeletextResponse.errorCode == "SP101");
        }

        #endregion

        #region WebAPI connection TestCase
        [TestMethod]
        public void TestSubtitleParseReturnAuthenticationfailed()
        {
            var request = new RestRequest("api/Teletext/SubtitleParse", Method.POST);
            request.OnBeforeDeserialization = resp => { resp.ContentType = "application/json"; };
            request.AddHeader("Accept-Encoding", "gzip,deflate");
            var byteArray = Encoding.ASCII.GetBytes("wrong" + ":" + "password");
            request.AddHeader("Authorization", "Basic " + Convert.ToBase64String(byteArray));
            request.RequestFormat = DataFormat.Json;
            TeletextRequest teletextRequest = new TeletextRequest
            {
                maxLengthOfSubtitle = 10,
                paragraphOfText = "kdfjdhgdhfghdg dhfghdflgdlg dfhgkdfgldf hdf gkdfgfd gfd g d g  h hkdfgdfhg"
            };
            request.AddBody(teletextRequest);
            request.Timeout = 240000;
            RestClient client = new RestClient("http://localhost:1025");
            client.AddHandler("application/json", new DynamicJsonDeserializer());
            var response = client.Execute<dynamic>(request);
            Assert.IsFalse(response.StatusCode.ToString().ToUpper() == "OK");
        }
        #endregion

        #region MVC TestCase
        [TestMethod]
        public void TestSubtitleParseReturnModel()
        {
            HomeController objHomeController = new HomeController();
            Teletext teletext = new Teletext();
            teletext.teletextRequest= new TeletextRequest{
            maxLengthOfSubtitle=5,
            paragraphOfText="dgjhdjjgkldfhglk,kfglkd."
            };
           ViewResult result = objHomeController.SplitSubtitle(teletext) as ViewResult;
           Assert.IsNotNull(result.Model);
        }
        #endregion

        
    }
}
