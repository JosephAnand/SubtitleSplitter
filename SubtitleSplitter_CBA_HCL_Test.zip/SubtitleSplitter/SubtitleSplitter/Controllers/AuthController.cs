﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace SubtitleSplitter.Controllers
{
    /// <summary>
    /// Here Basic Authentication implemented
    /// This class is used to authenticate user
    /// The credential is configured in web.config (ServerUsername and ServerPassword)
    /// </summary>
    public class AuthController : ApiController
    {
        static string ServerUsername = System.Web.Configuration.WebConfigurationManager.AppSettings["ServerUsername"].ToString();
        static string ServerPassword = System.Web.Configuration.WebConfigurationManager.AppSettings["ServerPassword"].ToString();
        #region Authentication

        public class AuthMessageHandler : DelegatingHandler
        {
            private const string BasicAuthResponseHeader = "WWW-Authenticate";
            private const string BasicAuthResponseHeaderValue = "Basic";

            public IProvidePrincipal PrincipalProvider { get; set; }

            protected override System.Threading.Tasks.Task<HttpResponseMessage> SendAsync(
                HttpRequestMessage request,
                CancellationToken cancellationToken)
            {
                
                AuthenticationHeaderValue authValue = request.Headers.Authorization;
                if (authValue != null && !String.IsNullOrWhiteSpace(authValue.Parameter))
                {
                    Credentials parsedCredentials = ParseAuthorizationHeader(authValue.Parameter.ToString());

                    if (parsedCredentials != null)
                    {
                        Thread.CurrentPrincipal = PrincipalProvider
                                .CreatePrincipal(parsedCredentials.Username, parsedCredentials.Password);
                    }
                }
                return base.SendAsync(request, cancellationToken)
                   .ContinueWith(task =>
                   {
                       var response = task.Result;
                       if (response.StatusCode == HttpStatusCode.Unauthorized
                           && !response.Headers.Contains(BasicAuthResponseHeader))
                       {
                           response.Headers.Add(BasicAuthResponseHeader
                               , BasicAuthResponseHeaderValue);
                       }


                      
                       return response;
                   });
            }

            private Credentials ParseAuthorizationHeader(string authHeader)
            {
                try
                {
                    var encoding = Encoding.GetEncoding("iso-8859-1");
                    var credentials = encoding.GetString(Convert.FromBase64String(authHeader));

                  
                    return new Credentials()
                    {

                        Username = credentials.Split(':')[0],
                        Password = credentials.Split(':')[1],
                    };
                }
                catch (Exception ex)
                {
                   
                    return null;
                }
                finally
                {
                }
            }
        }

        public class CorsHandler : DelegatingHandler
        {
            private const string Origin = "Origin";
            private const string AccessControlRequestMethod = "Access-Control-Request-Method";
            private const string AccessControlRequestHeaders = "Access-Control-Request-Headers";
            private const string AccessControlAllowOrigin = "Access-Control-Allow-Origin";
            private const string AccessControlAllowMethods = "Access-Control-Allow-Methods";
            private const string AccessControlAllowHeaders = "Access-Control-Allow-Headers";

            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                bool isCorsRequest = request.Headers.Contains(Origin);
                
                bool isPreRequest = request.Method == HttpMethod.Options;
                if (isCorsRequest)
                {
                    
                    if (isPreRequest)
                    {
                        var response = new HttpResponseMessage(HttpStatusCode.OK);
                        response.Headers.Add(AccessControlAllowOrigin, request.Headers.GetValues(Origin).First());

                        string accessControlRequestMethod = request.Headers.GetValues(AccessControlRequestMethod).FirstOrDefault();
                        if (accessControlRequestMethod != null)
                        {
                            response.Headers.Add(AccessControlAllowMethods, accessControlRequestMethod);
                        }

                        string requestedHeaders = string.Join(", ", request.Headers.GetValues(AccessControlRequestHeaders));
                        if (!string.IsNullOrEmpty(requestedHeaders))
                        {
                            response.Headers.Add(AccessControlAllowHeaders, requestedHeaders);
                        }

                        var tcs = new TaskCompletionSource<HttpResponseMessage>();
                        tcs.SetResult(response);
                        return tcs.Task;
                    }

                    return base.SendAsync(request, cancellationToken).ContinueWith(t =>
                    {
                        HttpResponseMessage resp = t.Result;
                        resp.Headers.Add(AccessControlAllowOrigin, request.Headers.GetValues(Origin).First());
                        return resp;
                    });
                }
                
                    return base.SendAsync(request, cancellationToken);
               }
        }

        public class Credentials
        {
            public string Usercategory { get; set; }
            public string Username { get; set; }
            public string Password { get; set; }
            public string Servicename { get; set; }
        }

        public interface IProvidePrincipal
        {
            IPrincipal CreatePrincipal(string username, string password);

        }

        public class PrincipalProvider : IProvidePrincipal
        {

           
            public IPrincipal CreatePrincipal(string username, string password)
            {

                if (!IsValidCredentialAndService(username, password))
                {
                    
                    return null;
                }

                var identity = new GenericIdentity(username);
                IPrincipal principal = new GenericPrincipal(identity, new[] { "User" });
                return principal;
            }

            private bool IsValidCredentialAndService(string username, string password)
            {
                if (username == ServerUsername && password == ServerPassword)
                    return true;
                return false;
            }
        }

        #endregion
    }
}
