﻿using SubtitleSplitter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SubtitleSplitter.Controllers
{

    /// <summary>
    /// This is webAPI Controller
    /// it will apply the 5 rules and get the subtitles
    /// </summary>
    public class TeletextController : ApiController
    {
        [Authorize]
        [HttpPost]
        public TeletextResponse SubtitleParse(TeletextRequest paragraph)
        {
            //Variable Declaration
            string paragraphOfText = paragraph.paragraphOfText;
            int maxLengthOfSubtitle = paragraph.maxLengthOfSubtitle;
            List<string> subTitleList = new List<string>();
            TeletextResponse teleTextResponse = null;
            string splittedText = string.Empty;
            int currentTextlength, commaPosition, sentencebreakPosition, brokenindex = 0;
           
            try
            {
                //Rule #5 - Remove duplicate spaces
                paragraphOfText = paragraphOfText.Replace("  ", "");
                currentTextlength = paragraphOfText.Length;
                while (currentTextlength > 0)
                {
                    //Rule #2 - Split the Line based on the character count
                    maxLengthOfSubtitle = currentTextlength <= maxLengthOfSubtitle ? currentTextlength : maxLengthOfSubtitle;
                    splittedText = paragraphOfText.Substring(0, maxLengthOfSubtitle);
                    //Rule #3 - Find the Line broken position
                    commaPosition = splittedText.IndexOf(',') == -1 ? 100 : splittedText.IndexOf(',');
                    sentencebreakPosition = splittedText.IndexOf('.') == -1 ? 100 : splittedText.IndexOf('.');
                    brokenindex = 0;
                    if (commaPosition != sentencebreakPosition)
                        brokenindex = commaPosition <= sentencebreakPosition ? commaPosition : sentencebreakPosition;
                    else
                        brokenindex = commaPosition;

                    if (brokenindex >= 0 && brokenindex < 5)
                    {
                        //Rule #4 - Broken line
                        subTitleList.Add(paragraphOfText.Substring(0, brokenindex + 1));
                        paragraphOfText = paragraphOfText.Remove(0, brokenindex + 1);
                    }
                    else
                    {
                        //Rule #1 - Perfect line
                        subTitleList.Add(splittedText);
                        paragraphOfText = paragraphOfText.Remove(0, maxLengthOfSubtitle);
                    }
                    currentTextlength = paragraphOfText.Length;
                }
                teleTextResponse = new TeletextResponse { subtitleText = subTitleList };
            }
            catch (Exception ex)
            {
                teleTextResponse = new TeletextResponse();
                teleTextResponse.errorCode = "SP101";
                teleTextResponse.errorMessage = ex.Message;
            }

            return teleTextResponse;
        }
    }
}