﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Deserializers;
using SubtitleSplitter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SubtitleSplitter.Utility
{
    public static class WebHelper
    {
        static string ClientUsername = System.Web.Configuration.WebConfigurationManager.AppSettings["ClientUsername"].ToString();
        static string ClientPassword = System.Web.Configuration.WebConfigurationManager.AppSettings["ClientPassword"].ToString();
        static string WebAPIURL = System.Web.Configuration.WebConfigurationManager.AppSettings["WebAPIURL"].ToString();
        /// <summary>
        /// Call WebAPI with client credential from web.config(ClientUsername,ClientPassword and WebAPIURL) using restsharp
        /// </summary>
        /// <param name="teletextRequest"></param>
        /// <returns></returns>
        public static JObject ApiServiceClient(TeletextRequest teletextRequest)
        {
            JObject jobj = null;
            try
            {
                var request = new RestRequest("api/Teletext/SubtitleParse", Method.POST);
                request.OnBeforeDeserialization = resp => { resp.ContentType = "application/json"; };
                request.AddHeader("Accept-Encoding", "gzip,deflate");
                var byteArray = Encoding.ASCII.GetBytes(ClientUsername + ":" + ClientPassword);
                request.AddHeader("Authorization","Basic "+ Convert.ToBase64String(byteArray)); 
                request.RequestFormat = DataFormat.Json;
                request.AddBody(teletextRequest);
                request.Timeout = 240000;
                RestClient client = new RestClient(WebAPIURL);
                client.AddHandler("application/json", new DynamicJsonDeserializer());
                var response = client.Execute<dynamic>(request);
                if (response != null && response.Data != null)
                    jobj = response.Data as JObject;

                if (response.StatusCode.ToString().ToUpper() != "OK")
                {
                    Error error = new Error();
                    error.errorCode = "401";

                    foreach (var item in jobj)
                        {
                            error.errorMessage = item.Value.ToString();
                    }

                    jobj = JsonConvert.DeserializeObject<dynamic>(JsonConvert.SerializeObject(error));
                }
            }
            catch (Exception ex)
            {
                // we can write the exception to error Log files ( Logging mechanism like Log4Net, etc)
            }
            finally
            {
            
            }
            return jobj;
        }
    }
    #region Json Deserializer
    public class DynamicJsonDeserializer : IDeserializer
    {
        public string RootElement { get; set; }
        public string Namespace { get; set; }
        public string DateFormat { get; set; }

        public T Deserialize<T>(IRestResponse response)
        {
            return JsonConvert.DeserializeObject<dynamic>(response.Content);
        }
    }
    #endregion


}