﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SubtitleSplitter.Models
{
    /// <summary>
    /// This entity to pass the paragraph of text for Split the text
    /// </summary>
    public class TeletextRequest
    {
        public int maxLengthOfSubtitle{get;set;}

        [Required(ErrorMessage="Please enter your Teletext Paragraph to split")]
        [StringLength(5000, MinimumLength = 1, ErrorMessage="The Teletext Paragraph character should be minimum of 1 and maximum of 5000 Characters")]
        public string paragraphOfText { get; set; }
    }

    /// <summary>
    ///  This entity to get the splited text to show the subtitle
    /// </summary>
    public class TeletextResponse : Error
    {
        public List<string> subtitleText { get; set; }
       
    }
    public class Error
    {
        public string errorCode{get;set;}
        public string errorMessage{get;set;}
    }

    public class Teletext
    {
        public TeletextRequest teletextRequest { get; set; }
        public TeletextResponse teletextResponse { get; set; }
    }
}